/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebaentrada;

/**
 *
 * @author JMRivera
 */
public class PruebaEntrada {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    // TODO code application logic here
    int nEntero;
    float nFloat;
    double nDouble;
    String cadena;
    char caracter;
    // Llamada a métodos con el parámetro mensaje
    // int
    nEntero = Entrada.leerEntero("Introduzca un entero:");
    System.out.println("Valor leido: "+nEntero);
    // float
    nFloat = Entrada.leerFloat("Introduzca un float:");
    System.out.println("Valor leido: "+nFloat);
    // double
    nDouble = Entrada.leerDouble("Introduzca un double:");
    System.out.println("Valor leido: "+nDouble);
    // String
    cadena = Entrada.leerCadena("Introduzca una cadena:");
    System.out.println("Valor leido: "+cadena);
    // char
    caracter = Entrada.leerCaracter("Introduzca un caracter:");
    System.out.println("Valor leido: "+caracter);
    // Llamada a métodos sin parámetros
    // el mensaje hay que escribirlo con System.out.println
    // int
    System.out.println("Introduzca un entero:");
    nEntero = Entrada.leerEntero();
    System.out.println("Valor leido: "+nEntero);
    // float
    System.out.println("Introduzca un float:");
    nFloat = Entrada.leerFloat();
    System.out.println("Valor leido: "+nFloat);
    // double
    System.out.println("Introduzca un double:");
    nDouble = Entrada.leerDouble();
    System.out.println("Valor leido: "+nDouble);
    // String
    System.out.println("Introduzca una cadena:");
    cadena = Entrada.leerCadena();
    System.out.println("Valor leido: "+cadena);
    // char
    System.out.println("Introduzca un caracter:");
    caracter = Entrada.leerCaracter();
    System.out.println("Valor leido: "+caracter);
  }
  
}
