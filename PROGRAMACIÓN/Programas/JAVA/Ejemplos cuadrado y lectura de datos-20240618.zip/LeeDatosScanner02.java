/**
*Lectura de datos desde teclado usando la clase Scanner
*
*@author Luis J. Sánchez
*/

import java.util.Scanner;

public class LeeDatosScanner02{
	public static void main(String[]args){
		Scanners = new Scanner(System.in); 
		
		System.out.print("Introduce tu nombrey tu edad separados por un espacio: ");
		String nombre = s.next();
		int edad = s.nextInt();
		
		System.out.println("Tunombre es " + nombre + "y tu edad es " + edad);
	}
}
