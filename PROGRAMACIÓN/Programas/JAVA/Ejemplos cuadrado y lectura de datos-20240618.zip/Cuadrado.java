package com.mycompany.prueba1;

/**
 *
 * @author jmrivera
 */
public class Cuadrado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //double x;
        final int TAM = 7;
		// Mostramos un cuadrado relleno
        System.out.println("Cuadrado relleno");
        for (int i = 1; i <= TAM;i++){
            for (int j = 1; j <= TAM;j++){
               System.out.print("* ");
            }
            System.out.println(""); // Salto de línea al terminar las columnas de una fila (bucle interno)
        }
		// Mostramos un cuadrado vacío
        System.out.println("Cuadrado vacío");
        for (int i = 1; i <= TAM;i++){
            for (int j = 1; j <= TAM;j++){
                if(i==1 || i == TAM) // si es la 1ª o la última fila
                    System.out.print("* ");
                else if(j==1 || j == TAM) // si es la 1ª o la última columna
                    System.out.print("* ");
                else
                    System.out.print("  "); // Dejamos los espacios en blanco interiores al cuadrado
            }
            System.out.println("");
        }
		// Mostramos un cuadrado con diagonal
        System.out.println("Cuadrado con diagonal");
        for (int i = 1; i <= TAM;i++){
            for (int j = 1; j <= TAM;j++){
                if(i==1 || i == TAM || i == j) // Añadimos la condición de diagonal "i == j"
                    System.out.print("* ");
                else if(j==1 || j == TAM)
                    System.out.print("* ");
                else
                    System.out.print("  ");
            }
            System.out.println("");
        }
    }
    
}
