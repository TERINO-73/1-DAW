
package vectores;

import java.util.Scanner;

/**
 *
 * @author jmrivera
 */
public class Vectores {
	// Definición del vector
    private static int[ ] notas;
	// Constante con el número de posiciones del vector
    final static int POS = 5; 

    /**
     * @param args the command line arguments
     */
    public static void main(String[ ] args) {
        int dato = 0;
        float media = 0;
		// Crear el vector
        notas = new int[POS];
		// Leer por teclado los valores del vector
        for (int i=0; i<notas.length; i++) { 
            System.out.print("Introduzca nota "+(i+1)+": ");
            dato = Entrada.leerEntero();
            notas[i] = dato;
        }
		// Calcular la media y mostrarla
        for (int i=0; i<POS; i++) { 
            media += notas[i];
        }
        media = media / notas.length;
        System.out.println("La nota media es: " + media);
        
		// Crear una matriz a partir de los datos
        int [ ][ ] matriz = { {1, 4, 5},{6, 2, 5} };
        System.out.println("La matriz tiene por filas el valor: " + matriz.length);
        System.out.println("La matriz tiene por columnas el valor: " + matriz[0].length);
        
		// Mostrar la matriz
		for(int i = 0; i < matriz.length; i++){
            for(int j = 0; j < matriz[0].length; j++){
                System.out.print(" "+matriz[i][j]);
            }
            System.out.println("");
        }
        
    }
}
    

