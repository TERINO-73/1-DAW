/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionarempresa;

/**
 *
 * @author JMRivera
 */
public class Programador extends Empleado{
  
  private int horasExtras;

  public Programador(int horasExtras, String nombre, String dni, double salario) {
    super(nombre, dni, salario);
    this.horasExtras = horasExtras;
  }

  public int getHorasExtras() {
    return horasExtras;
  }

  public void setHorasExtras(int horasExtras) {
    this.horasExtras = horasExtras;
  }

  @Override
  public double extras() {
    return horasExtras * 20;
  }

  @Override
  public void datosEmpleados() {
    System.out.println("Programador");
    super.datosEmpleados();
    System.out.println("Horas extras: "+horasExtras);
  }
  
  
  
}
