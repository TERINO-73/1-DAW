/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionarempresa;

/**
 *
 * @author JMRivera
 */
public class Gerente extends Empleado{
  
  private double comision;
  private int proyectos;

  public Gerente(double comision, int proyectos, String nombre, String dni, double salario) {
    super(nombre, dni, salario);
    this.comision = comision;
    this.proyectos = proyectos;
  }

  public int getProyectos() {
    return proyectos;
  }

  public void setProyectos(int proyectos) {
    this.proyectos = proyectos;
  }

  public double getComision() {
    return comision;
  }

  public void setComision(double comision) {
    this.comision = comision;
  }

  @Override
  public double extras() {
    return comision * proyectos;
  }

  @Override
  public void datosEmpleados() {
    System.out.println("Gerente");
    super.datosEmpleados();
    System.out.println("Comisión: "+comision);
    System.out.println("Proyectos: "+proyectos);
  }
  
  
  
}
