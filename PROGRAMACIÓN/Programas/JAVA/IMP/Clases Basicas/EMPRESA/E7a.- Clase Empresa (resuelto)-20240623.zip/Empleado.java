/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionarempresa;

/**
 *
 * @author JMRivera
 */
public abstract class Empleado {
  
  private String nombre;
  private String dni;
  private double salario;
  private Cuenta cuentaEmpleado;

  public Empleado(String nombre, String dni, double salario) {
    this.nombre = nombre;
    this.dni = dni;
    this.salario = salario;
    this.cuentaEmpleado = new Cuenta(nombre, dni, 5, salario);
  }

  public String getNombre() {
    return nombre;
  }

  public void setNombre(String nombre) {
    this.nombre = nombre;
  }

  public String getDni() {
    return dni;
  }

  public void setDni(String dni) {
    this.dni = dni;
  }

  public double getSalario() {
    return salario;
  }

  public void setSalario(double salario) {
    this.salario = salario;
  }

  public abstract double extras();
  
  public void datosEmpleados(){
    System.out.println("Nombre: "+nombre);
    System.out.println("DNI: "+dni);
    System.out.println("Salario: "+salario);
    System.out.println("Extras: "+extras());
    System.out.println(cuentaEmpleado.toString());
  }

  public Cuenta getCuentaEmpleado() {
    return cuentaEmpleado;
  }

  public void setCuentaEmpleado(Cuenta cuentaEmpleado) {
    this.cuentaEmpleado = cuentaEmpleado;
  }
  
  
}
