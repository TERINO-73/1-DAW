/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionarempresa;

import java.util.Scanner;

/**
 *
 * @author JMRivera
 */
public class GestionarEmpresa {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Empresa miEmpresa = new Empresa("Paquetes S.A.", "A41234567", 1000000);
    int opcion, posicion;
    char modificar;
    Empleado miEmpleado;
    double importe;
    
    do{
      opcion = menu();
      switch(opcion){
        case 1:
          System.out.println("\nDatos de la empresa:");
          miEmpresa.datosEmpresa();
          modificar = Entrada.leerCaracter("¿Quiere modificar los datos (s/n)?:");
          if (modificar == 's'){
            miEmpresa.setNombreEmpresa(Entrada.leerCadena("Nuevo nombre:"));
            miEmpresa.setCif(Entrada.leerCadena("Nuevo CIF:"));
          }
          break;
        case 2:
          miEmpleado = pedirDatosEmpleados();
          if (miEmpresa.contratar(miEmpleado)){
            System.out.println("Contratado.");
          }else{
            System.out.println("Error en la contratación.");
          }
          break;
        case 3:
          posicion = Entrada.leerEntero("Número del empleado:");
          miEmpleado = miEmpresa.devolverEmpleado(posicion);
          if (miEmpleado != null){
            miEmpleado.datosEmpleados();
          }
          break;

        case 4:
          miEmpresa.listarEmpleados();
          break;
        case 5:
          System.out.println("Pagando nóminas y extras:");
          for(int i = 0; i < miEmpresa.getNumeroEmpleados(); i++){
            if(!miEmpresa.pagarNomina(i)){
              System.out.println("Error pagando nómina empleado: "+miEmpresa.devolverEmpleado(i).getDni());
            }else{
              System.out.println("Pagada la nómina del empleado: "+miEmpresa.devolverEmpleado(i).getDni());
            }
          }
          break;
        case 6:
          importe = Entrada.leerDouble("Importe a ingresar:");
          if (!miEmpresa.getCuentaEmpresa().ingreso(importe)){
            System.out.println("Error ingresando: "+importe);
          }else{
            System.out.println("Importe ingresado.");
          }
          break;
      }
      Entrada.leerCadena("Pulse intro para continuar...");
    }while(opcion != 0);
  }
  
  public static int menu(){
    int op;
    System.out.println("Menu");
    System.out.println("");
    System.out.println("1.- Ver/modificar los datos de la empresa.");
    System.out.println("2.- Contratar a un empleado.");
    System.out.println("3.- Ver los datos de un empleado.");
    System.out.println("4.- Ver los datos de todos los empleado.");
    System.out.println("5.- Pagar todas las nóminas.");
    System.out.println("6.- Ingresar en la cuenta de la empresa.");
    System.out.println("0.- Salir.");
    op = Entrada.leerEntero("\nElija opción:");

    return op;
  }
  /**
   * 
   * @return 
   */
  public static Empleado pedirDatosEmpleados(){
    Empleado e = null;
    char tipoEmpleado;
    String nombre, dni;
    double salario, comision;
    int horasExtras, proyectos; 
    
    tipoEmpleado = Entrada.leerCaracter("\nTipo del nuevo empleado (programador/gerente):");
    if (tipoEmpleado == 'p' || tipoEmpleado == 'g'){
      nombre = Entrada.leerCadena("Nombre:");
      dni = Entrada.leerCadena("DNI:");
      salario = Entrada.leerDouble("Salario:");
      switch(tipoEmpleado){
        case 'p':
          horasExtras = Entrada.leerEntero("Horas extras:");
          e = new Programador(horasExtras, nombre, dni, salario);
          break;
        case 'g':
          comision = Entrada.leerDouble("Comisión:");
          proyectos = Entrada.leerEntero("Número de proyectos:");
          e = new Gerente(comision, proyectos, nombre, dni, salario);
          break;
      }
    }
    return e;
  }
}
