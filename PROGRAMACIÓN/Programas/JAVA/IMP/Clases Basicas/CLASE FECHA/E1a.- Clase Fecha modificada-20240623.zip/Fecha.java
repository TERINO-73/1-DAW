/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebafecha;

/**
 *
 * @author JMRivera
 */
public class Fecha {

    private int dia;
    private int mes;
    private int annio;

    public Fecha(int dia, int mes, int annio) {
        this.dia = dia;
        this.mes = mes;
        this.annio = annio;
    }

    public Fecha() {
        this.dia = 1;
        this.mes = 1;
        this.annio = 2000;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(dia);
        sb.append("/").append(mes);
        sb.append("/").append(annio);
        return sb.toString();
    }

/*
    @Override
    public String toString() {
        return dia + "/" + mes + "/" + annio;
    }
    
 */
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnnio() {
        return annio;
    }

    public void setAnnio(int annio) {
        this.annio = annio;
    }

    public boolean esBisiesto(int annio) {
        return (annio % 4 == 0) && (!(annio % 100 == 0) || (annio % 400 == 0));
    }

    public boolean comprobarFecha() {
        boolean diaValido, mesValido, anioValido;
        mesValido = (mes >= 1 && mes <= 12);
        anioValido = (annio > 0);
        switch (mes) {
            case 2:
                if (esBisiesto(annio)) {
                    diaValido = dia >= 1 && dia <= 29;
                } else {
                    diaValido = dia >= 1 && dia <= 28;
                }
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                diaValido = dia >= 1 && dia <= 30;
                break;
            default:
                diaValido = dia >= 1 && dia <= 31;
        }

        return diaValido && mesValido && anioValido;
    }

    public void diaSiguiente() {
        dia++;
        if (!comprobarFecha()) {
            dia = 1;
            mes++;
            if (!comprobarFecha()) {
                mes = 1;
                annio++;
            }
        }
    }
    
    
}
